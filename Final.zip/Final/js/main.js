function grossIncome() {
    let rate = parseInt(document.getElementById('rate').value);
    let hour = parseInt(document.getElementById('hour').value);
    let income = document.getElementById('grossIncome');
    let overRate = document.getElementById('overRate');

    if (hour <= 40) {
        income.innerHTML = (rate * hour), 10;
    } else if (hour > 40) {
        overRate = (0.2 * rate) + rate

        income.innerHTML = ((rate * 40) + ((hour - 40) * overRate)), 10;
    }

}

function fToC() {
    let fahrenheit = document.getElementById('fahrenheit').value;
    let celsius = (fahrenheit - 32) * 5 / 9;
    if (celsius < 0) {
        document.getElementById('celsius').innerHTML = celsius + " °C, It's Freezing!";
    } else if (celsius > 30) {
        document.getElementById('celsius').innerHTML = celsius + " °C, It's too hot!";
    } else {
        document.getElementById('celsius').innerHTML = celsius + " °C";
    }
}

function result() {

    if (document.getElementById("correct1").checked && document.getElementById("correct2").checked) {
        alert("“You made it, 2 of 2! ");
    } else if (document.getElementById("correct1").checked || document.getElementById("correct2").checked) {
        alert("1 of 2! Good job. ");
    } else {
        alert("0 of 2. You should study more! ");
    }

}