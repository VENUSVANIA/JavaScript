let name = prompt("hello, what is your name?");
document.getElementById("demo").innerHTML = "Hello " + name;

function toC() {
    let celsius = parseInt(document.getElementById('celsius').value);

    celsius = ((celsius - 32) * 5 / 9);
    document.getElementById("result").innerHTML = celsius;
}

function king() {

    if (document.getElementById('lion').checked) {
        document.getElementById('true').innerHTML = "Correct";

    } else if (document.getElementById('snake').checked) {
        document.getElementById('true').innerHTML = "TryAgain";

    } else if (document.getElementById('turtle').checked) {
        document.getElementById('true').innerHTML = "TryAgain";

    } else {
        document.getElementById('true').innerHTML = "select something"
    }
}

function check() {

    let number = parseInt(document.getElementById('number1').value);

    if (number < 0) {
        document.getElementById('number').innerHTML = " You're kidding right?";
    } else if (number == 0) {
        document.getElementById('number').innerHTML = " Oh Baby, how can you work with computer that early in life!";

    } else if (number <= 100) {
        document.getElementById('number').innerHTML = "You Can play!";
    } else if (number > 100) {
        document.getElementById('number').innerHTML = "You're too Old to Play!'";

    } else {
        document.getElementById('number').innerHTML = " Enter Age";
    }
}

function odd() {

    let numb = parseInt(document.getElementById('numb1').value);

    if (numb % 2 == 0) {
        document.getElementById('numb').innerHTML = "EVEN!";
    } else {
        document.getElementById('numb').innerHTML = " ODD!";
    }

}